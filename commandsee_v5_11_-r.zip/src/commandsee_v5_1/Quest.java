package commandsee_v5_1;

import java.util.ArrayList;

import org.bukkit.World;
import org.bukkit.command.CommandSender;

public class Quest {
	CommandSender sender;
	ArrayList<Ppcmd> type;
	ArrayList<World> world;
	ArrayList<String> command;
	ArrayList<String> player = null;
	int range;
	public Quest(CommandSender a, ArrayList<Ppcmd> b, ArrayList<World> c, ArrayList<String> d, int r) {
		sender = a;
		type = b;
		world = c;
		command = d;
		range = r;
	}
	public Quest(CommandSender a, ArrayList<Ppcmd> b, ArrayList<World> c, ArrayList<String> d, ArrayList<String> player2, int r) {
		sender = a;
		type = b;
		world = c;
		command = d;
		player = player2;
		range = r;
	}
	public ArrayList<String> getCommand() {
		return command;
	}
	public CommandSender getSender() {
		return sender;
	}
	public ArrayList<Ppcmd> getType() {
		return type;
	}
	public ArrayList<World> getWorld() {
		return world;
	}
	public ArrayList<String> getPlayer() {
		return player;
	}
	public int getRange() {
		return range;
	}
}
